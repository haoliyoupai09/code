function paths = env_paths_tracking(varargin)
    paths.net_base = 'E:\tracking\tracking code\cfnet\cfnet-master\pretrained\networks\'; % e.g. '/home/luca/cfnet/networks/';
    paths.eval_set_base = 'E:\tracking\tracking code\cfnet\cfnet-master\data\'; % e.g. '/home/luca/cfnet/data/';
    paths.stats = 'E:\tracking\tracking code\cfnet\cfnet-master\data\ILSVRC2015.stats.mat'; % e.g.'/home/luca/cfnet/data/ILSVRC2015.stats.mat';
    paths = vl_argparse(paths, varargin);
end
