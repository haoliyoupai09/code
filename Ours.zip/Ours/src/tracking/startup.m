addpath(genpath('your path to matconvnet')); % edit
addpath(genpath('../util'));
vl_setupnn;
