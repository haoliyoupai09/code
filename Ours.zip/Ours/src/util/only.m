function e = only(x)
assert(numel(x) == 1);
e = x{1};
end
