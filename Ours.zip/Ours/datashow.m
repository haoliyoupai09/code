clc;
clear all;
[m, n, c] = size(z_out_val{1});

% ��ʾ����
figure();
[x,y,z] = meshgrid(1:1:m,1:1:n,1:1:c);
v = z_out_val{1};
xs = 1:1:m;
ys = 1:1:n;
zs = 1:1:c;
h = slice(x,y,z,v,xs,ys,zs);
set(h,'FaceColor','interp','EdgeColor','none');
camproj perspective
box on
colormap hsv
colorbar