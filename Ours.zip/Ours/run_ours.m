function results = run_CFnet_ECO_colorwindow(seq, res_path, bSaveImage)
 % rename OTBReadyTracker to the name of the tracker you are using in the OTB evaluation
    tracker_params.gpus = 1;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    addpath(genpath('E:\tracking\tracking code\cfnet\cfnet-master\matconvnet-1.0-beta22\'));
    addpath(genpath('E:\tracking\tracking code\cfnet\cfnet-master\matconvnet-1.0-beta22\matlab\mex\')); 

%     tracker_params.net = 'cfnet-conv2_e80.mat';
%     tracker_params.net_gray = 'cfnet-conv2_gray_e40.mat';
%     tracker_params.visualization = false;
%     tracker_params.join.method = 'corrfilt'; % or 'xcorr'
    tracker_params.net = 'baseline-conv5_e55.mat';
    tracker_params.net_gray = 'baseline-conv5_gray_e100.mat';
    tracker_params.visualization = false;
    tracker_params.join.method = 'xcorr'; % or 'xcorr'
    root_folder = '';
    % % hyperparameters that work well for the tracker version you are using
    % tracker_params.scaleStep = 
    % tracker_params.scalePenalty = 
    % tracker_params.scaleLR = 
    % tracker_params.wInfluence = 
    % tracker_params.zLR =  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    tracker_params.imgFiles = vl_imreadjpeg(strcat(root_folder,seq.s_frames),'numThreads', 12);
    [cx, cy, w, h] = get_axis_aligned_BB(seq.init_rect);
    tracker_params.targetPosition = [cy cx];
    tracker_params.targetSize = round([h w]);
    % Call the main tracking function
    [bboxes, speed] = tracker(tracker_params);
    results = struct();
    results.res = bboxes;
    results.type = 'rect';
    results.fps = speed;
end
